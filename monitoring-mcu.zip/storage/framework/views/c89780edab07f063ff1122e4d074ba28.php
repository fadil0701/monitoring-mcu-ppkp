

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="page-title">Selamat Datang, <?php echo e(Auth::user()->name); ?>!</h1>
                <p class="text-muted">Dashboard monitoring MCU PPKP DKI Jakarta</p>
            </div>
            <div class="text-end">
                <small class="text-muted">Terakhir diperbarui: <?php echo e(now()->format('d/m/Y H:i')); ?></small>
            </div>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stats-number"><?php echo e($participant ? '1' : '0'); ?></div>
            <div class="stats-label">Status Pendaftaran</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-calendar-check"></i>
            </div>
            <div class="stats-number"><?php echo e($schedules->count()); ?></div>
            <div class="stats-label">Jadwal MCU</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-file-medical"></i>
            </div>
            <div class="stats-number"><?php echo e($mcuResults->count()); ?></div>
            <div class="stats-label">Hasil MCU</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stats-number">
                <?php if($participant && $participant->tanggal_mcu_terakhir): ?>
                    <?php echo e(\Carbon\Carbon::parse($participant->tanggal_mcu_terakhir)->diffForHumans()); ?>

                <?php else: ?>
                    Belum MCU
                <?php endif; ?>
            </div>
            <div class="stats-label">MCU Terakhir</div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Profile Status -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-user-circle me-2"></i>Status Profile
                </h5>
            </div>
            <div class="card-body">
                <?php if($participant): ?>
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <div class="user-avatar" style="width: 60px; height: 60px; font-size: 1.5rem;">
                                <?php echo e(strtoupper(substr($participant->nama_lengkap, 0, 1))); ?>

                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-1"><?php echo e($participant->nama_lengkap); ?></h6>
                            <p class="text-muted mb-1"><?php echo e($participant->skpd); ?></p>
                            <span class="badge bg-<?php echo e($participant->status_mcu_color); ?>">
                                <?php echo e($participant->status_mcu); ?>

                            </span>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <small class="text-muted">NIK KTP</small>
                            <p class="mb-2"><strong><?php echo e($participant->nik_ktp); ?></strong></p>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">Status Pegawai</small>
                            <p class="mb-2"><strong><?php echo e($participant->status_pegawai); ?></strong></p>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">Umur</small>
                            <p class="mb-2"><strong><?php echo e($participant->umur); ?> tahun</strong></p>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">Jenis Kelamin</small>
                            <p class="mb-2"><strong><?php echo e($participant->jenis_kelamin_text); ?></strong></p>
                        </div>
                    </div>
                    
                    <a href="<?php echo e(route('client.profile')); ?>" class="btn btn-primary w-100">
                        <i class="fas fa-edit me-2"></i>Lihat Profile Lengkap
                    </a>
                <?php else: ?>
                    <div class="text-center py-4">
                        <div class="mb-3">
                            <i class="fas fa-user-slash fa-3x text-muted"></i>
                        </div>
                        <h6>Data Profile Belum Lengkap</h6>
                        <p class="text-muted mb-3">Silakan lengkapi data profile Anda untuk dapat mengakses fitur MCU.</p>
                        <a href="<?php echo e(route('client.profile')); ?>" class="btn btn-primary">
                            <i class="fas fa-user-plus me-2"></i>Lengkapi Profile
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>Aksi Cepat
                </h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6">
                        <a href="<?php echo e(route('client.schedules')); ?>" class="btn btn-outline-primary w-100 h-100 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-calendar fa-2x mb-2"></i>
                            <span>Jadwal MCU</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?php echo e(route('client.results')); ?>" class="btn btn-outline-success w-100 h-100 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-file-medical fa-2x mb-2"></i>
                            <span>Hasil MCU</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?php echo e(route('client.profile')); ?>" class="btn btn-outline-info w-100 h-100 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-user fa-2x mb-2"></i>
                            <span>Profile</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" 
                           class="btn btn-outline-danger w-100 h-100 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-sign-out-alt fa-2x mb-2"></i>
                            <span>Logout</span>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activities -->
<div class="row">
    <!-- Upcoming Schedules -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-calendar-alt me-2"></i>Jadwal MCU Terdekat
                </h5>
            </div>
            <div class="card-body">
                <?php if($schedules->count() > 0): ?>
                    <?php $__currentLoopData = $schedules->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center mb-3 p-3 border rounded">
                            <div class="flex-shrink-0">
                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" 
                                     style="width: 50px; height: 50px;">
                                    <i class="fas fa-calendar-check"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1"><?php echo e($schedule->tanggal_pemeriksaan_formatted); ?></h6>
                                <p class="text-muted mb-1"><?php echo e($schedule->jam_pemeriksaan_formatted); ?> - <?php echo e($schedule->lokasi_pemeriksaan); ?></p>
                                <span class="badge bg-<?php echo e($schedule->status_color); ?>">
                                    <?php echo e($schedule->status); ?>

                                </span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('client.schedules')); ?>" class="btn btn-outline-primary w-100">
                        <i class="fas fa-eye me-2"></i>Lihat Semua Jadwal
                    </a>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h6>Belum Ada Jadwal MCU</h6>
                        <p class="text-muted">Jadwal MCU akan muncul setelah Anda didaftarkan oleh administrator.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent Results -->
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-line me-2"></i>Hasil MCU Terbaru
                </h5>
            </div>
            <div class="card-body">
                <?php if($mcuResults->count() > 0): ?>
                    <?php $__currentLoopData = $mcuResults->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center mb-3 p-3 border rounded">
                            <div class="flex-shrink-0">
                                <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" 
                                     style="width: 50px; height: 50px;">
                                    <i class="fas fa-file-medical"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1"><?php echo e($result->tanggal_pemeriksaan_formatted); ?></h6>
                                <p class="text-muted mb-1">
                                    <?php if($result->diagnosis): ?>
                                        <?php echo e(Str::limit($result->diagnosis, 30)); ?>

                                    <?php else: ?>
                                        Tidak ada diagnosis
                                    <?php endif; ?>
                                </p>
                                <span class="badge bg-<?php echo e($result->status_kesehatan_color); ?>">
                                    <?php echo e($result->status_kesehatan); ?>

                                </span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('client.results')); ?>" class="btn btn-outline-success w-100">
                        <i class="fas fa-eye me-2"></i>Lihat Semua Hasil
                    </a>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-file-medical fa-3x text-muted mb-3"></i>
                        <h6>Belum Ada Hasil MCU</h6>
                        <p class="text-muted">Hasil MCU akan muncul setelah pemeriksaan selesai dan diupload oleh administrator.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- System Information -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>Informasi Sistem
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-shield-alt fa-2x text-primary mb-2"></i>
                            <h6>Sistem Aman</h6>
                            <p class="text-muted small">Data Anda dilindungi dengan sistem keamanan tingkat tinggi</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-clock fa-2x text-warning mb-2"></i>
                            <h6>24/7 Tersedia</h6>
                            <p class="text-muted small">Sistem dapat diakses kapan saja dan di mana saja</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-headset fa-2x text-success mb-2"></i>
                            <h6>Dukungan Penuh</h6>
                            <p class="text-muted small">Tim support siap membantu Anda kapan saja</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\monitoring-mcu\resources\views/client/dashboard.blade.php ENDPATH**/ ?>