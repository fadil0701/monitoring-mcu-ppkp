<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ClientController;
use Illuminate\Support\Facades\Route;

// Redirect root to client dashboard
Route::get('/', function () {
    return redirect('/client/dashboard');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Client routes
Route::prefix('client')->middleware(['auth'])->group(function () {
    Route::get('/dashboard', [ClientController::class, 'dashboard'])->name('client.dashboard');
    Route::get('/profile', [ClientController::class, 'profile'])->name('client.profile');
    Route::get('/schedules', [ClientController::class, 'schedules'])->name('client.schedules');
    Route::get('/results', [ClientController::class, 'results'])->name('client.results');
    Route::get('/results/{result}/download', [ClientController::class, 'downloadResult'])->name('client.results.download');
});

require __DIR__.'/auth.php';
