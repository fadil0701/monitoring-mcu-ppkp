@extends('client.layout')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0">Jadwal MCU Saya</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    @if($schedules->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal Pemeriksaan</th>
                                        <th>Jam</th>
                                        <th>Lokasi</th>
                                        <th>Status</th>
                                        <th>Email Sent</th>
                                        <th>WhatsApp Sent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($schedules as $index => $schedule)
                                    <tr>
                                        <td>{{ $index + 1 }}</td>
                                        <td>
                                            <strong>{{ $schedule->tanggal_pemeriksaan_formatted }}</strong>
                                            @if($schedule->isToday())
                                                <span class="badge bg-warning ms-2">Hari Ini</span>
                                            @elseif($schedule->isPast())
                                                <span class="badge bg-secondary ms-2">Sudah Lewat</span>
                                            @elseif($schedule->isFuture())
                                                <span class="badge bg-info ms-2">Akan Datang</span>
                                            @endif
                                        </td>
                                        <td>{{ $schedule->jam_pemeriksaan_formatted }}</td>
                                        <td>{{ $schedule->lokasi_pemeriksaan }}</td>
                                        <td>
                                            <span class="badge bg-{{ $schedule->status_color }}">
                                                {{ $schedule->status }}
                                            </span>
                                        </td>
                                        <td>
                                            @if($schedule->email_sent)
                                                <span class="badge bg-success">
                                                    <i class="fas fa-check"></i> Terkirim
                                                </span>
                                            @else
                                                <span class="badge bg-secondary">
                                                    <i class="fas fa-times"></i> Belum
                                                </span>
                                            @endif
                                        </td>
                                        <td>
                                            @if($schedule->whatsapp_sent)
                                                <span class="badge bg-success">
                                                    <i class="fas fa-check"></i> Terkirim
                                                </span>
                                            @else
                                                <span class="badge bg-secondary">
                                                    <i class="fas fa-times"></i> Belum
                                                </span>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        @if($schedules->hasPages())
                            <div class="d-flex justify-content-center mt-4">
                                {{ $schedules->links() }}
                            </div>
                        @endif
                    @else
                        <div class="text-center py-5">
                            <div class="mb-3">
                                <i class="fas fa-calendar-times fa-3x text-muted"></i>
                            </div>
                            <h5>Belum Ada Jadwal MCU</h5>
                            <p class="text-muted">Anda belum memiliki jadwal MCU yang terjadwal.</p>
                            <p class="text-muted">Silakan hubungi administrator untuk penjadwalan MCU.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    @if($schedules->count() > 0)
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Statistik Jadwal</h5>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card bg-primary text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title">Total Jadwal</h6>
                                    <h3 class="mb-0">{{ $schedules->total() }}</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title">Selesai</h6>
                                    <h3 class="mb-0">{{ $schedules->where('status', 'Selesai')->count() }}</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-warning text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title">Terjadwal</h6>
                                    <h3 class="mb-0">{{ $schedules->where('status', 'Terjadwal')->count() }}</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-danger text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title">Dibatalkan</h6>
                                    <h3 class="mb-0">{{ $schedules->where('status', 'Batal')->count() }}</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection
