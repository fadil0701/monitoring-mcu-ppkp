<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;

class McuResult extends Model
{
    use HasFactory;

    protected $fillable = [
        'participant_id',
        'schedule_id',
        'tanggal_pemeriksaan',
        'diagnosis',
        'hasil_pemeriksaan',
        'status_kesehatan',
        'rekomendasi',
        'file_hasil',
        'is_downloaded',
        'downloaded_at',
        'uploaded_by',
    ];

    protected $casts = [
        'tanggal_pemeriksaan' => 'date',
        'is_downloaded' => 'boolean',
        'downloaded_at' => 'datetime',
    ];

    public function participant(): BelongsTo
    {
        return $this->belongsTo(Participant::class);
    }

    public function schedule(): BelongsTo
    {
        return $this->belongsTo(Schedule::class);
    }

    public function getStatusKesehatanColorAttribute(): string
    {
        return match($this->status_kesehatan) {
            'Sehat' => 'success',
            'Kurang Sehat' => 'warning',
            'Tidak Sehat' => 'danger',
            default => 'secondary',
        };
    }

    public function getTanggalPemeriksaanFormattedAttribute(): string
    {
        return $this->tanggal_pemeriksaan->format('d/m/Y');
    }

    public function getFileUrlAttribute(): string
    {
        if ($this->file_hasil) {
            return asset('storage/' . $this->file_hasil);
        }
        return '';
    }

    public function markAsDownloaded(): void
    {
        $this->update([
            'is_downloaded' => true,
            'downloaded_at' => Carbon::now(),
        ]);
    }

    public function hasFile(): bool
    {
        return !empty($this->file_hasil);
    }
}
