<?php

namespace App\Http\Controllers;

use App\Models\Participant;
use App\Models\Schedule;
use App\Models\McuResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClientController extends Controller
{
    public function dashboard()
    {
        $user = Auth::user();
        $participant = null;
        $schedules = collect();
        $mcuResults = collect();

        if ($user->nik_ktp) {
            $participant = Participant::where('nik_ktp', $user->nik_ktp)->first();
            
            if ($participant) {
                $schedules = $participant->schedules()->orderBy('tanggal_pemeriksaan', 'desc')->get();
                $mcuResults = $participant->mcuResults()->orderBy('tanggal_pemeriksaan', 'desc')->get();
            }
        }

        return view('client.dashboard', compact('participant', 'schedules', 'mcuResults'));
    }

    public function profile()
    {
        $user = Auth::user();
        $participant = null;

        if ($user->nik_ktp) {
            $participant = Participant::where('nik_ktp', $user->nik_ktp)->first();
        }

        return view('client.profile', compact('participant'));
    }

    public function schedules()
    {
        $user = Auth::user();
        $schedules = collect();

        if ($user->nik_ktp) {
            $participant = Participant::where('nik_ktp', $user->nik_ktp)->first();
            
            if ($participant) {
                $schedules = $participant->schedules()->orderBy('tanggal_pemeriksaan', 'desc')->paginate(10);
            }
        }

        return view('client.schedules', compact('schedules'));
    }

    public function results()
    {
        $user = Auth::user();
        $mcuResults = collect();

        if ($user->nik_ktp) {
            $participant = Participant::where('nik_ktp', $user->nik_ktp)->first();
            
            if ($participant) {
                $mcuResults = $participant->mcuResults()->orderBy('tanggal_pemeriksaan', 'desc')->paginate(10);
            }
        }

        return view('client.results', compact('mcuResults'));
    }

    public function downloadResult($id)
    {
        $user = Auth::user();
        $mcuResult = McuResult::findOrFail($id);

        // Check if user has access to this result
        if ($user->nik_ktp && $mcuResult->participant->nik_ktp === $user->nik_ktp) {
            if ($mcuResult->hasFile()) {
                $mcuResult->markAsDownloaded();
                return response()->download(storage_path('app/public/' . $mcuResult->file_hasil));
            }
        }

        abort(404);
    }
}
