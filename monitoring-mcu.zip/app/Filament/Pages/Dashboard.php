<?php

namespace App\Filament\Pages;

use App\Models\Participant;
use App\Models\Schedule;
use App\Models\McuResult;
use App\Models\User;
use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';

    protected static string $view = 'filament.pages.dashboard';

    public function getTitle(): string
    {
        return 'Dashboard MCU PPKP DKI Jakarta';
    }
}
