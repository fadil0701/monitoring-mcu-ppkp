<?php

namespace App\Filament\Widgets;

use App\Models\Participant;
use App\Models\McuResult;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Carbon;

class McuChart extends ChartWidget
{
    protected static ?string $heading = 'Statistik MCU';

    protected function getData(): array
    {
        $months = collect();
        for ($i = 5; $i >= 0; $i--) {
            $months->push(Carbon::now()->subMonths($i)->format('M Y'));
        }

        $participantsData = $months->map(function ($month) {
            return Participant::whereMonth('created_at', Carbon::parse($month))
                ->whereYear('created_at', Carbon::parse($month))
                ->count();
        });

        $mcuResultsData = $months->map(function ($month) {
            return McuResult::whereMonth('created_at', Carbon::parse($month))
                ->whereYear('created_at', Carbon::parse($month))
                ->count();
        });

        return [
            'datasets' => [
                [
                    'label' => 'Peserta Baru',
                    'data' => $participantsData->toArray(),
                    'borderColor' => '#3b82f6',
                    'backgroundColor' => '#3b82f6',
                ],
                [
                    'label' => 'Hasil MCU',
                    'data' => $mcuResultsData->toArray(),
                    'borderColor' => '#10b981',
                    'backgroundColor' => '#10b981',
                ],
            ],
            'labels' => $months->toArray(),
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }
}
