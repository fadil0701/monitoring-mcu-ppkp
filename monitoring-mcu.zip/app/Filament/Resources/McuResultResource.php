<?php

namespace App\Filament\Resources;

use App\Filament\Resources\McuResultResource\Pages;
use App\Models\McuResult;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Actions\Action;
use Illuminate\Database\Eloquent\Builder;

class McuResultResource extends Resource
{
    protected static ?string $model = McuResult::class;

    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected static ?string $navigationGroup = 'MCU Management';

    protected static ?int $navigationSort = 3;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Participant & Schedule Information')
                    ->schema([
                        Select::make('participant_id')
                            ->relationship('participant', 'nama_lengkap')
                            ->searchable()
                            ->preload()
                            ->required()
                            ->label('Participant')
                            ->afterStateUpdated(function ($state, callable $set) {
                                if ($state) {
                                    $participant = \App\Models\Participant::find($state);
                                    if ($participant) {
                                        $set('tanggal_pemeriksaan', $participant->tanggal_mcu_terakhir ?? now());
                                    }
                                }
                            }),
                        
                        Select::make('schedule_id')
                            ->relationship('schedule', 'id', function (Builder $query) {
                                return $query->where('status', 'Selesai');
                            })
                            ->searchable()
                            ->preload()
                            ->label('Schedule (Optional)')
                            ->placeholder('Select if related to a specific schedule'),
                    ])
                    ->columns(2),

                Section::make('Examination Results')
                    ->schema([
                        DatePicker::make('tanggal_pemeriksaan')
                            ->required()
                            ->label('Examination Date')
                            ->maxDate(now()),
                        
                        TextInput::make('diagnosis')
                            ->label('Diagnosis')
                            ->placeholder('Enter diagnosis if any'),
                        
                        Textarea::make('hasil_pemeriksaan')
                            ->required()
                            ->label('Examination Results')
                            ->rows(4)
                            ->placeholder('Enter detailed examination results'),
                        
                        Select::make('status_kesehatan')
                            ->options([
                                'Sehat' => 'Healthy',
                                'Kurang Sehat' => 'Less Healthy',
                                'Tidak Sehat' => 'Unhealthy',
                            ])
                            ->required()
                            ->label('Health Status'),
                        
                        Textarea::make('rekomendasi')
                            ->label('Recommendations')
                            ->rows(3)
                            ->placeholder('Enter health recommendations'),
                    ])
                    ->columns(2),

                Section::make('File Upload')
                    ->schema([
                        FileUpload::make('file_hasil')
                            ->label('Result File')
                            ->directory('mcu-results')
                            ->acceptedFileTypes(['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/*'])
                            ->maxSize(10240) // 10MB
                            ->helperText('Upload PDF, DOC, DOCX, or image files (max 10MB)')
                            ->downloadable()
                            ->previewable(),
                    ])
                    ->collapsible(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('participant.nama_lengkap')
                    ->label('Participant Name')
                    ->searchable()
                    ->sortable(),
                
                TextColumn::make('participant.nik_ktp')
                    ->label('NIK KTP')
                    ->searchable(),
                
                TextColumn::make('tanggal_pemeriksaan')
                    ->label('Examination Date')
                    ->date()
                    ->sortable(),
                
                TextColumn::make('diagnosis')
                    ->label('Diagnosis')
                    ->limit(30)
                    ->searchable(),
                
                BadgeColumn::make('status_kesehatan')
                    ->colors([
                        'success' => 'Sehat',
                        'warning' => 'Kurang Sehat',
                        'danger' => 'Tidak Sehat',
                    ])
                    ->label('Health Status'),
                
                TextColumn::make('participant.skpd')
                    ->label('SKPD')
                    ->searchable(),
                
                IconColumn::make('is_downloaded')
                    ->boolean()
                    ->label('Downloaded')
                    ->trueIcon('heroicon-o-check-circle')
                    ->falseIcon('heroicon-o-x-circle')
                    ->trueColor('success')
                    ->falseColor('danger'),
                
                TextColumn::make('uploaded_by')
                    ->label('Uploaded By')
                    ->searchable(),
                
                TextColumn::make('created_at')
                    ->label('Created')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('status_kesehatan')
                    ->options([
                        'Sehat' => 'Healthy',
                        'Kurang Sehat' => 'Less Healthy',
                        'Tidak Sehat' => 'Unhealthy',
                    ])
                    ->label('Health Status'),
                
                SelectFilter::make('skpd')
                    ->relationship('participant', 'skpd')
                    ->label('SKPD'),
                
                Filter::make('tanggal_pemeriksaan')
                    ->form([
                        DatePicker::make('from')
                            ->label('From Date'),
                        DatePicker::make('until')
                            ->label('Until Date'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['from'],
                                fn (Builder $query, $date): Builder => $query->whereDate('tanggal_pemeriksaan', '>=', $date),
                            )
                            ->when(
                                $data['until'],
                                fn (Builder $query, $date): Builder => $query->whereDate('tanggal_pemeriksaan', '<=', $date),
                            );
                    })
                    ->label('Examination Date Range'),
                
                Filter::make('is_downloaded')
                    ->form([
                        Forms\Components\Toggle::make('is_downloaded')
                            ->label('Downloaded'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query->when(
                            $data['is_downloaded'],
                            fn (Builder $query, $isDownloaded): Builder => $query->where('is_downloaded', $isDownloaded),
                        );
                    })
                    ->label('Download Status'),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
                
                Action::make('download_file')
                    ->label('Download File')
                    ->icon('heroicon-o-arrow-down-tray')
                    ->color('success')
                    ->url(fn (McuResult $record): string => $record->hasFile() ? $record->file_url : '#')
                    ->openUrlInNewTab()
                    ->visible(fn (McuResult $record): bool => $record->hasFile()),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    
                    Action::make('export_results')
                        ->label('Export Results')
                        ->icon('heroicon-o-arrow-down-tray')
                        ->color('success')
                        ->action(function (array $records) {
                            // Export logic here
                            \Filament\Notifications\Notification::make()
                                ->title('Export completed')
                                ->success()
                                ->send();
                        }),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMcuResults::route('/'),
            'create' => Pages\CreateMcuResult::route('/create'),
            'edit' => Pages\EditMcuResult::route('/{record}/edit'),
        ];
    }
}
